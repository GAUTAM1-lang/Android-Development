package com.example.splitscreenapp1

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION){
    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "YourAppDB"
        private const val TABLE_NAME = "Data"
        private const val COLUMN_DATE = "date"
        private const val COLUMN_VALUE = "value"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = "CREATE TABLE $TABLE_NAME ($COLUMN_DATE TEXT PRIMARY KEY, $COLUMN_VALUE TEXT)"
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Handle database upgrades if needed
    }

    fun saveData(date: String, value: String): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COLUMN_DATE, date)
        contentValues.put(COLUMN_VALUE, value)

        return db.insert(TABLE_NAME, null, contentValues)
    }

    fun getData(date: String): String? {
        val db = this.readableDatabase
        val query = "SELECT $COLUMN_VALUE FROM $TABLE_NAME WHERE $COLUMN_DATE = ?"
        val cursor = db.rawQuery(query, arrayOf(date))

        var value: String? = null
        if (cursor.moveToFirst()) {
            val columnIndex = cursor.getColumnIndex(COLUMN_VALUE)
            if (columnIndex >= 0) {
                value = cursor.getString(columnIndex)
            } else {
                // Handle the case where the column index is -1 (column not found)
                // You may want to log an error message or handle this situation differently
            }
        }

        cursor.close()
        return value
    }
    fun updateData(date: String, newValue: String): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COLUMN_VALUE, newValue)

        return db.update(TABLE_NAME, contentValues, "$COLUMN_DATE = ?", arrayOf(date))
    }

    fun deleteData(date: String): Int {
        val db = this.writableDatabase
        return db.delete(TABLE_NAME, "$COLUMN_DATE = ?", arrayOf(date))
    }
}