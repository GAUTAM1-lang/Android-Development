package com.example.splitscreenapp1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    private lateinit var selectedDateTextView: TextView
    private lateinit var inputValueEditText: EditText
    private lateinit var submitButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        selectedDateTextView = findViewById(R.id.selectedDateTextView)
        inputValueEditText = findViewById(R.id.inputValueEditText)
        submitButton = findViewById(R.id.submitButton)

        val selectedDate = intent.getStringExtra("selectedDate")
        selectedDateTextView.text = selectedDate

        // Check if input values exist in local DB for the selected date and populate EditText if found

        // Set listener for submit button
        submitButton.setOnClickListener {
            // Save input values in local DB against the selected date

            // You need to implement the logic to save data to local database here
        }

    }
}