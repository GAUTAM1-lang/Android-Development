package com.example.splitscreenapp1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Spinner

class MainActivity : AppCompatActivity() {
    private lateinit var monthSpinner: Spinner
    private lateinit var yearSpinner: Spinner
    private lateinit var dateListView: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       monthSpinner = findViewById(R.id.monthSpinner)
        yearSpinner = findViewById(R.id.yearSpinner)
        dateListView = findViewById(R.id.dateListView)

        // Populate month spinner
        val months = resources.getStringArray(R.array.months)
        val monthAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, months)
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        monthSpinner.adapter = monthAdapter

        // Populate year spinner
        val years = generateYears(1980, 2040)
        val yearAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, years)
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        yearSpinner.adapter = yearAdapter

        // Set listener for date selection
        dateListView.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(position) as String
            // Navigate to second screen with selected date
            navigateToSecondScreen(selectedItem)
        }

        // Populate list view based on selected month and year
        populateListView(monthSpinner.selectedItem.toString(), yearSpinner.selectedItem.toString())

        // Set listener for month and year selection
        monthSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                populateListView(monthSpinner.selectedItem.toString(), yearSpinner.selectedItem.toString())
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        yearSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                populateListView(monthSpinner.selectedItem.toString(), yearSpinner.selectedItem.toString())
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun populateListView(month: String, year: String) {
        // Your logic to populate list view based on month and year
        // For example, if you have an array of dates for the selected month and year, you can use an ArrayAdapter to populate the ListView
        val dates = generateDates(month, year)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dates)
        dateListView.adapter = adapter
    }

    private fun navigateToSecondScreen(selectedDate: String) {
        val intent = Intent(this, SecondActivity::class.java)
        intent.putExtra("selectedDate", selectedDate)
        startActivity(intent)
    }

    private fun generateYears(startYear: Int, endYear: Int): Array<String> {
        return (startYear..endYear).map { it.toString() }.toTypedArray()
    }

    private fun generateDates(month: String, year: String): Array<String> {
        // Your logic to generate dates for the selected month and year
        // For example, you can calculate the number of days in the month and year and generate dates accordingly
        // This is just a placeholder example
        return (1..31).map { it.toString() }.toTypedArray()
    }


}